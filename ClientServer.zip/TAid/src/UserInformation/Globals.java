package UserInformation;



public class Globals 
{
	public static String ipAddress = "192.168.1.73";
	public static int port = 6889;
}
