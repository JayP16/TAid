package UserInformation;

import java.io.Serializable;

public abstract class User implements Serializable
{
	protected String username;
	protected String password;
	
	public User(String username, String password)
	{
		this.username = username;
		this.password = password;
	}
	
	public String getUsername()
	{
		return username;
	}
	
	public String getPassword()
	{
		return password;
	}
	
	protected void changePassword(String newPassword)
	{
		password = newPassword;
	}
}
