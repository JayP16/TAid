package com.example.taid;

import junit.framework.TestCase;

public class DisplayMessageActivityTest extends TestCase {

	public DisplayMessageActivityTest(String name) {
		super(name);
	}

	protected void setUp() throws Exception {
		super.setUp();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}

	public void testOnCreateBundle() {
		fail("Not yet implemented"); // TODO
	}

	public void testOnOptionsItemSelectedMenuItem() {
		fail("Not yet implemented"); // TODO
	}

}
